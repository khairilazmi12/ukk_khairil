<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulir Pembelian</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #34495e;
            color: #ecf0f1;
        }

        #header {
            background-color: #3498db;
            color: #fff;
            padding: 20px;
            text-align: center;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
            margin-bottom: 20px;
            position: relative;
        }

        #header::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background: url('your-ornament-image.jpg') repeat;
            opacity: 0.2;
            top: 0;
            left: 0;
            z-index: -1;
        }

        #welcome {
            font-size: 28px;
            font-weight: bold;
        }

        #menu-container {
            text-align: center;
            margin-top: 20px;
        }

        #menu {
            display: inline-block;
        }

        #menu a {
            margin: 0 10px;
            padding: 12px 24px;
            text-decoration: none;
            background-color: #2ecc71;
            color: #fff;
            border-radius: 8px;
            transition: background-color 0.3s ease;
            font-size: 18px;
            font-weight: bold;
        }

        #menu a.logout {
            background-color: #e74c3c;
        }

        #menu a:hover {
            background-color: #27ae60;
        }

        h2 {
            text-align: center;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 16px;
        }

        a {
            display: block;
            margin-top: 10px;
            text-decoration: none;
            color: #3498db;
        }

        a:hover {
            color: #1f618d;
        }

        button {
            background-color: #3498db;
            color: #fff;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #1f618d;
        }
    </style>
</head>

<body>

    <div id="header">
        <div id="welcome">
            <h2>Formulir Pembelian</h2>
        </div>
    </div>

    <form action="tambah_pembelian.php" method="POST">
        <label for="pelanggan">Pilih Pelanggan:</label>
        <select id="pelanggan" name="pelanggan">
            <?php
            include '../config.php';
            $sql = "SELECT PelangganID, NamaPelanggan FROM pelanggan";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value='" . $row['PelangganID'] . "'>" . $row['NamaPelanggan'] . "</option>";
                }
            } else {
                echo "<option value=''>Tidak ada pelanggan</option>";
            }

            mysqli_close($conn);
            ?>
        </select>
        <a href="tambah_pelanggan.php">Tambah Pelanggan Baru</a>
        <button type="submit">Submit</button>
    </form>

</body>

</html>
            