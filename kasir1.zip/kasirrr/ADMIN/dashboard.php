<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #34495e;
            color: #ecf0f1;
        }

        #header {
            background-color: #3498db;
            color: #fff;
            padding: 20px;
            text-align: center;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
            margin-bottom: 20px;
            position: relative;
        }

        #header::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background: url('your-ornament-image.jpg') repeat;
            opacity: 0.2;
            top: 0;
            left: 0;
            z-index: -1;
        }

        #welcome {
            font-size: 28px;
            font-weight: bold;
        }

        #menu-container {
            text-align: center;
            margin-top: 20px;
        }

        #menu {
            display: inline-block;
        }

        #menu a {
            margin: 0 10px;
            padding: 12px 24px;
            text-decoration: none;
            background-color: #2ecc71;
            color: #fff;
            border-radius: 8px;
            transition: background-color 0.3s ease;
            font-size: 18px;
            font-weight: bold;
        }

        #menu a.logout {
            background-color: #e74c3c;
        }

        #menu a:hover {
            background-color: #27ae60;
        }
    </style>
</head>

<body>

    <div id="header">
        <div id="welcome">
            <h2>Selamat Datang</h2>
        </div>
    </div>

    <div id="menu-container">
        <div id="menu">
            <a href="pembelian.php">Pembelian</a>
            <a href="stok_barang.php">Stock Barang</a>
            <a href="detail_penjualan.php">Detail Penjualan</a>
            <a href="../register.php">Register</a>
            <?php
            // Periksa apakah level sudah di-set dan tidak null sebelum mengakses
            if(isset($_SESSION['level']) && $_SESSION['level'] == 'admin') {
                echo '<a href="data_petugas.php">Data Petugas</a>';
            } 
            ?>
            <a href="logout.php" class="logout">Logout</a>
        </div>
    </div>

</body>

</html>
