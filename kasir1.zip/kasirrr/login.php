<?php
// Koneksi ke database
$servername = "localhost";
$username = "root"; // Ganti dengan username MySQL Anda
$password = ""; // Ganti dengan password MySQL Anda
$dbname = "kasir1";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi Gagal: " . $conn->connect_error);
}

// Fungsi untuk login
function loginUser($conn, $username, $password) {
    $stmt = $conn->prepare("SELECT * FROM user WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user["password"])) {
        return $user;
    } else {
        return null;
    }
}

// Form submit
// Form submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Login
    $user = loginUser($conn, $username, $password);

    if ($user) {
        // Set session untuk menyimpan informasi login
        session_start();
        $_SESSION["userID"] = $user["id"];
        $_SESSION["username"] = $user["username"];

        // Arahkan ke dashboard sesuai dengan peran pengguna setelah login berhasil
        if ($user["role"] == "admin") {
            header("Location: ADMIN/dashboard.php");
        } else {
            header("Location: ADMIN/user_dashboard.php");
        }
        exit();
    } else {
        echo "Login gagal. Periksa kembali username dan password Anda.";
    }
}


$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Login</h2>
    <form method="post" action="">
        <label>Username:</label>
        <input type="text" name="username" required><br>
        
        <label>Password:</label>
        <input type="password" name="password" required><br>
        
        <input type="submit" value="Login">
    </form>
    <div class="register">
</html>
